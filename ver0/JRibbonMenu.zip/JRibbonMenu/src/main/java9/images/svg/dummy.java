package images.svg;

public @interface dummy {

}
