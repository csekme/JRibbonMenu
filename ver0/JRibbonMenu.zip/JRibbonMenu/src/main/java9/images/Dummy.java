// empty class used for module export support

package images;

public class Dummy {

}
